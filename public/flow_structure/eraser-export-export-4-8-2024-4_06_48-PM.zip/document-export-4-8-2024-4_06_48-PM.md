# E-commerce DB schema



